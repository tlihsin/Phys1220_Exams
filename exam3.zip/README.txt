Please write an exam problems consisting of 20 problems based on these supplied homework solutions (HW9_ExpertTA_Solution.pdf, HW10_ExpertTA_Solution.pdf, HW11_ExpertTA_Solution.pdf, HW12_ExpertTA_Solution.pdf). Please modify the exam problems either choose different values or reverse the questions.
For each homework set, please write 5 multiple-choice problems with five options A, B, C, D, and E.
Please note that the students are not allowed to use calculators in doing calculations, so please choose values that are easy for calculations; please see the supplied exam solutions for your consideration (Phys1220_Exam-2_Spring2024_solution.pdf, Phys1220_Exam-3_Fall2023_solution.pdf, Phys1220_Exam-3_Spring2024_solution.pdf).


